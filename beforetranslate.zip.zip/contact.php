<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];
    $messageType = $_POST['messageType'];

    // Simple validation (you may want to add more validation)
    if (!empty($name) && !empty($email) && !empty($message)) {
        $to = "test@zhelyo.boostyourday.net"; // Your email address
        $subject = "New Contact Message from $name: $messageType";
        $body = "Name: $name\nEmail: $email\n\nMessage:\n$message";
        $headers = "From: $email";

        if (mail($to, $subject, $body, $headers)) {
            echo "Message sent successfully.";
        } else {
            echo "Message sending failed.";
        }
    } else {
        echo "All fields are required.";
    }
}
?>