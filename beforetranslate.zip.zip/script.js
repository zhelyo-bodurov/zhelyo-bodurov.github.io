document.addEventListener("DOMContentLoaded", () => {
    const loader = document.getElementById("loader");
    const body = document.body;

    // Function to hide loader and show content
    const hideLoader = () => {
        loader.style.display = "none";
        body.classList.add("fade-in");
    };

    // Hide loader after a short delay
    setTimeout(hideLoader, 1000); // 1 second delay

    // Form submission handling
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();

            const formData = new FormData(contactForm);
            const formMessage = document.getElementById('formMessage');

            // Send form data using Fetch API
            fetch('contact.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                formMessage.textContent = data;
                formMessage.style.color = data.includes("successfully") ? '#080D0A' : '#F2522E';
                if (data.includes("successfully")) {
                    contactForm.reset();
                }
            })
            .catch(() => {
                formMessage.textContent = 'An error occurred. Please try again.';
                formMessage.style.color = '#F2522E'; // Error color
            });
        });
    }

    // Handle flip card click events
    const flipCards = document.querySelectorAll('.flip-card');
    flipCards.forEach(card => {
        card.addEventListener('click', () => {
            card.classList.toggle('flipped');
        });
    });

    // Scroll to Top Button functionality
    const myButton = document.getElementById("myBtn");

    // Show the button when the user scrolls down 20px from the top of the document
    window.onscroll = () => {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            myButton.style.display = "block";
        } else {
            myButton.style.display = "none";
        }
    };

    // Scroll to the top when the user clicks the button
    myButton.onclick = () => {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    };
});
